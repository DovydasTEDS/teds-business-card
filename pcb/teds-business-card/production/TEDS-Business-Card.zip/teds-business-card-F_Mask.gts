G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-05-25T12:01:21+01:00*
G04 #@! TF.ProjectId,teds-business-card,74656473-2d62-4757-9369-6e6573732d63,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-05-25 12:01:21*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
